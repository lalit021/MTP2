#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image, PointCloud2
from std_msgs.msg import Bool
from cv_bridge import CvBridge
import numpy as np
import cv2
import time
import sensor_msgs.point_cloud2 as pc2

try:
    import pyrealsense2 as rs
    REALSENSE_AVAILABLE = True
except ImportError:
    REALSENSE_AVAILABLE = False

class CameraPublisher:
    def __init__(self, use_realsense=True):
        rospy.init_node('camera_image_publisher', anonymous=True)

        # Publishers
        self.publisher = rospy.Publisher('/camera/color/image_raw', Image, queue_size=10)
        self.depth_publisher = rospy.Publisher('/camera/depth/image_raw', Image, queue_size=10)
        self.pointcloud_publisher = rospy.Publisher('/camera/point_cloud', PointCloud2, queue_size=10)
        self.heartbeat_pub = rospy.Publisher('/camera/heartbeat', Bool, queue_size=10)
        self.bridge = CvBridge()

        self.use_realsense = use_realsense and REALSENSE_AVAILABLE
        self.pipeline = None
        self.config = None
        self.last_heartbeat = time.time()
        self.last_publish_success = False  # Track last state to reduce logging

        if self.use_realsense:
            self.initialize_realsense()
        else:
            rospy.logwarn("Using regular webcam (not RealSense).")
            self.cap = cv2.VideoCapture(0)  # Default to laptop/webcam

    def initialize_realsense(self):
        """Attempts to initialize the RealSense pipeline."""
        try:
            rospy.loginfo("Initializing RealSense camera...")
            self.pipeline = rs.pipeline()
            self.config = rs.config()
            self.config.enable_stream(rs.stream.color, 640, 480, rs.format.bgr8, 30)
            self.config.enable_stream(rs.stream.depth, 640, 480, rs.format.z16, 30)
            self.pipeline.start(self.config)
            rospy.loginfo("RealSense camera initialized successfully.")
        except Exception as e:
            rospy.logerr("Failed to initialize RealSense camera: {}".format(e))
            self.pipeline = None

    def publish_image(self):
        image_success = False  # Track current image capture success

        if self.use_realsense:
            if not self.pipeline:
                rospy.logwarn("RealSense pipeline is not active. Attempting to reconnect...")
                self.initialize_realsense()
                return
            
            try:
                frames = self.pipeline.wait_for_frames(timeout_ms=500)
                color_frame = frames.get_color_frame()
                depth_frame = frames.get_depth_frame()
                if not color_frame or not depth_frame:
                    rospy.logwarn("No frame received. Camera might be disconnected.")
                    return

                color_image = np.asanyarray(color_frame.get_data())
                depth_image = np.asanyarray(depth_frame.get_data())
                image_success = True

                # Apply colormap to depth image for heatmap visualization
                depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_image, alpha=0.03), cv2.COLORMAP_JET)

                # Get the 3D points (vertices) for the point cloud
                pc = rs.pointcloud()
                pc.map_to(color_frame)
                points = pc.calculate(depth_frame)
                vertices = np.asanyarray(points.get_vertices())

            except Exception as e:
                rospy.logwarn("Error capturing RealSense image: {}. Trying to reconnect...".format(e))
                self.initialize_realsense()
                return
        else:
            # Regular webcam capture (no depth image available)
            ret, color_image = self.cap.read()
            if not ret:
                rospy.logwarn("Could not access webcam.")
                return
            image_success = True
            depth_colormap = None  # No depth image for webcam
            vertices = None  # No point cloud for webcam

        if image_success and not self.last_publish_success:
            rospy.loginfo("Image stream resumed.")

        self.last_publish_success = image_success

        ros_image = self.bridge.cv2_to_imgmsg(color_image, encoding='bgr8')
        self.publisher.publish(ros_image)

        # Publish depth image with colormap
        if depth_colormap is not None:
            ros_depth_image = self.bridge.cv2_to_imgmsg(depth_colormap, encoding='bgr8')
            self.depth_publisher.publish(ros_depth_image)

        # Publish point cloud (3D vertices)
        if vertices is not None:
            # Create a PointCloud2 message
            header = rospy.Header()
            header.stamp = rospy.Time.now()
            header.frame_id = "camera_link"

            # Create point cloud data (x, y, z coordinates)
            points = [(v[0], v[1], v[2]) for v in vertices]
            point_cloud_msg = pc2.create_cloud_xyz32(header, points)
            self.pointcloud_publisher.publish(point_cloud_msg)

        # Publish heartbeat every 5 seconds
        if time.time() - self.last_heartbeat > 5:
            self.heartbeat_pub.publish(True)
            self.last_heartbeat = time.time()

    def spin(self):
        rate = rospy.Rate(10)
        while not rospy.is_shutdown():
            self.publish_image()
            rate.sleep()

    def cleanup(self):
        if self.pipeline:
            self.pipeline.stop()
        if hasattr(self, 'cap'):
            self.cap.release()
        cv2.destroyAllWindows()
        rospy.loginfo("CameraPublisher shutdown complete.")

if __name__ == '__main__':
    rospy.init_node('camera_image_publisher', anonymous=True)

    # Get ROS parameter (instead of using argparse)
    use_realsense = rospy.get_param("~realsense", True)

    publisher = None
    try:
        publisher = CameraPublisher(use_realsense=use_realsense)
        publisher.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Shutting down camera publisher node.")
    finally:
        if publisher:
            publisher.cleanup()
