#!/usr/bin/env python
import rospy
import os
import csv
import rospkg
import numpy as np
import cv2
from sensor_msgs.msg import Image, PointCloud2
from cv_bridge import CvBridge
import sensor_msgs.point_cloud2 as pc2
from PIL import Image as PILImage
import time
import tf2_ros
import geometry_msgs.msg

# Get the package path using rospkg
rospack = rospkg.RosPack()
pkg_path = rospack.get_path('aruco_pose')  # Replace with your actual package name
csv_file = os.path.join(pkg_path, 'detected_points.csv')  # Adjust path as needed

class PointCloudSubscriber:
    def __init__(self):
        rospy.init_node('pointcloud_subscriber', anonymous=True)

        self.image_subscriber = rospy.Subscriber('/camera/color/image_raw', Image, self.image_callback)
        self.pointcloud_subscriber = rospy.Subscriber('/camera/point_cloud', PointCloud2, self.pointcloud_callback)

        self.bridge = CvBridge()
        self.color_image = None
        self.point_cloud = None
        self.image_received = False
        self.pointcloud_received = False

        # Initialize the tf broadcaster
        self.tf_broadcaster = tf2_ros.TransformBroadcaster()

    def image_callback(self, msg):
        self.color_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        self.image_received = True

    def pointcloud_callback(self, msg):
        pc_data = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)
        self.point_cloud = list(pc_data)
        self.pointcloud_received = True

    def get_3d_coordinates(self, pixel_x, pixel_y):
        if not self.image_received or not self.pointcloud_received:
            rospy.logwarn("Waiting for image and point cloud data...")
            return None, None, None

        height, width, _ = self.color_image.shape
        index = pixel_y * width + pixel_x
        if index < len(self.point_cloud):
            x, y, z = self.point_cloud[index]
            return x, y, z
        else:
            return None, None, None

    def display_image_with_coordinates(self, points, coordinates):
        if self.color_image is not None:
            for (px, py), (x, y, z) in zip(points, coordinates):
                cv2.circle(self.color_image, (px, py), 5, (0, 0, 255), -1)
                text = "X: {:.2f}, Y: {:.2f}, Z: {:.2f}".format(x, y, z)
                cv2.putText(self.color_image, text, (px + 10, py + 10), cv2.FONT_HERSHEY_SIMPLEX,
                            0.5, (0, 255, 0), 2)
            cv2.imshow("Image with 3D Coordinates", self.color_image)
            cv2.waitKey(1)

    def publish_transform(self, point_id, x, y, z):
        transform = geometry_msgs.msg.TransformStamped()
        transform.header.stamp = rospy.Time.now()
        transform.header.frame_id = "camera_link"  # base link frame
        transform.child_frame_id = "detected_point_" + str(point_id)  # Unique frame for each detected point

        transform.transform.translation.x = x
        transform.transform.translation.y = y
        transform.transform.translation.z = z
        transform.transform.rotation.x = 0.0
        transform.transform.rotation.y = 0.0
        transform.transform.rotation.z = 0.0
        transform.transform.rotation.w = 1.0

        self.tf_broadcaster.sendTransform(transform)

    def cleanup(self):
        cv2.destroyAllWindows()


def process_csv_and_map_points(csv_file, subscriber):
    points = []
    coordinates = []

    try:
        with open(csv_file, mode='r') as file:
            reader = csv.reader(file)
            header = next(reader, None)  # Skip header
            for row in reader:
                if len(row) < 3:
                    rospy.logwarn("Skipping incomplete row: {}".format(row))
                    continue

                frame_no = row[0]
                prompt = row[1]

                try:
                    model_output = eval(row[2])  # Convert string of pixel tuples to list
                except Exception as e:
                    rospy.logwarn("Failed to parse model output in row: {}. Error: {}".format(row, e))
                    continue

                print("Processing Frame {} with prompt: {}".format(frame_no, prompt))

                for idx, (px, py) in enumerate(model_output):
                    x, y, z = subscriber.get_3d_coordinates(px, py)
                    if x is not None and y is not None and z is not None:
                        points.append((px, py))
                        coordinates.append((x, y, z))

                        # Publish transform for each point
                        subscriber.publish_transform(idx, x, y, z)
                    else:
                        print("Warning: No 3D data for pixel ({}, {})".format(px, py))

            subscriber.display_image_with_coordinates(points, coordinates)

    except IOError as e:
        rospy.logwarn("Error reading CSV file: {}".format(e))
    except Exception as e:
        rospy.logwarn("Unexpected error while processing CSV: {}".format(e))


if __name__ == '__main__':
    subscriber = PointCloudSubscriber()

    try:
        rate = rospy.Rate(1)  # 1 Hz loop
        while not rospy.is_shutdown():
            if subscriber.image_received and subscriber.pointcloud_received:
                process_csv_and_map_points(csv_file, subscriber)
            rate.sleep()
    except rospy.ROSInterruptException:
        pass
    finally:
        subscriber.cleanup()
